﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing.Drawing2D;
using System.Data;
using System.Data.SqlClient;

public partial class Default5 : System.Web.UI.Page
{
    public static string a;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        Button3.Visible = false;
      TextBox2.Visible = false;
        string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=G:\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        SqlDataAdapter d = new SqlDataAdapter();
        DataTable t = new DataTable();

        d = new SqlDataAdapter("select * from notice", con);
        d.Fill(t);
       Label2.Text = t.Rows[0]["notice"].ToString();

                 if (Session["admin"] != null)
                 {
                     Button2.Visible = true;
                    // Button4.Visible = true;

                    // Label2.Visible = false;
                 }
                 else if (Session["student"] != null)
                 {
                     TextBox2.Visible = false;
                     Button2.Visible = true;
                     Label1.Visible = false;
                 }
                 else if (Session["teacher"] != null)
                 {
                     TextBox2.Visible = false;
                     Button2.Visible = true;
                     Label1.Visible = false;
                 }
             
             else { Response.Redirect("index.aspx");}

    }
  
    
    protected void Button2_Click(object sender, EventArgs e)
    {

        if (Session["admin"] != null)
        {
            // Session.RemoveAll();  
            Session.RemoveAll();
          //  Session["abc"] = "abc";
            Response.Redirect("index.aspx");

        }

        else if (Session["student"] != null)
        {
            // Session.RemoveAll();  
            Session.RemoveAll();
          //  Session["abc"] = "abc";
            Response.Redirect("index.aspx");

        }

        if (Session["teacher"] != null)
        {
            // Session.RemoveAll();  
            Session.RemoveAll();
            //Session["abc"] = "abc";
            Response.Redirect("index.aspx");

        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
       // TextBox2.ReadOnly = false;
        TextBox2.Enabled = true;

        string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=G:\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        SqlDataAdapter d = new SqlDataAdapter();
        DataTable t = new DataTable();

        d = new SqlDataAdapter("select * from notice", con);
        d.Fill(t);
        TextBox2.Text = t.Rows[0]["notice"].ToString();
        TextBox2.Enabled = true;
       //Button1.CssClass = "ab";

       // Button1.Visible = false;
        Button3.Visible = true;
        TextBox2.Visible = true;
        this.Visible = false;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        //Label3.Text = TextBox1.Text;

        string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=G:\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        SqlDataAdapter d = new SqlDataAdapter();
        DataTable t = new DataTable();
      //  Response.Redirect("sdfsdf"+TextBox1.Text);
        d = new SqlDataAdapter("update notice set notice='"+TextBox2.Text+"' where sno=1", con);
        //Label3.Text = TextBox2.Text;
        //d.SelectCommand.Parameters.AddWithValue("a", TextBox1.Text);
        d.Fill(t);
       // TextBox1.Text = "";
       // TextBox1.Text = t.Rows[0]["notice"].ToString();
        Response.Redirect("home.aspx");
        Button3.Visible = false;
        TextBox2.Visible = false;

    }
    
}
    
