﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class teacher : System.Web.UI.Page
{
    public static string a;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["teacher"] != null)
        {
            a = Session["teacher"].ToString();

            string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=G:\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            SqlDataAdapter d = new SqlDataAdapter();
            DataTable t = new DataTable();
            //TextBox1.Text= Session["student"].ToString().Trim();
            d = new SqlDataAdapter("select * from usr where type='Teacher'", con);
            d.Fill(t);
            //TextBox1.Text = t.Rows[0]["name"].ToString();
            for (int i = 0; i < t.Rows.Count; i++)
            {
                if (t.Rows[i]["name"].ToString().Trim() == Session["teacher"].ToString().Trim())
                {
                    TextBox1.Text = t.Rows[0]["name"].ToString();
                    TextBox1.ReadOnly = true;
                    TextBox2.Text = t.Rows[0]["username"].ToString();
                    TextBox2.ReadOnly = true;
                    TextBox3.Text = t.Rows[0]["email"].ToString();
                    break;
                }
                // else { Response.Redirect("home.aspx"); }

            }
        }
        else
        {
            Response.Redirect("loginn.aspx");
        }
       
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("loginn.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lokesh\Desktop\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        SqlDataAdapter d = new SqlDataAdapter();
        DataTable t = new DataTable();

        d = new SqlDataAdapter("insert into teacher values(@a,@b,@c,@d,@e,@f,@g)", con);

        d.SelectCommand.Parameters.AddWithValue("a", TextBox1.Text);
        d.SelectCommand.Parameters.AddWithValue("b", TextBox2.Text);
        d.SelectCommand.Parameters.AddWithValue("c", TextBox3.Text);
        d.SelectCommand.Parameters.AddWithValue("d", TextBox4.Text);
        d.SelectCommand.Parameters.AddWithValue("e", TextBox5.Text);
        d.SelectCommand.Parameters.AddWithValue("f", TextBox6.Text);
        d.SelectCommand.Parameters.AddWithValue("g", TextBox7.Text);

        d.Fill(t);

    }
}