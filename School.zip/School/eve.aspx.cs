﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            string filename = FileUpload1.FileName;
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Data/" + filename));


        }
        foreach (string strfilename in Directory.GetFiles(Server.MapPath("~/Data/")))
        {

            ImageButton imagebutton = new ImageButton();
            FileInfo fileinfo = new FileInfo(strfilename);
            imagebutton.ImageUrl = "~/Data/" + fileinfo.Name;
            imagebutton.Width = Unit.Pixel(300);
            imagebutton.Height = Unit.Pixel(300);
            imagebutton.Style.Add("padding", "5px");
            imagebutton.Click += new ImageClickEventHandler(imagebutton_Click);
            Panel1.Controls.Add(imagebutton);
        }

    }
    public static string a;
    void imagebutton_Click(object sender, ImageClickEventArgs e)
    {

        ImageButton imagebutton = new ImageButton();
        //FileInfo fileinfo = new FileInfo(imagebutton.ImageUrl);
        //imagebutton.ImageUrl = "~/Data/" + fileinfo.Name;
        a = imagebutton.ImageUrl;
        Response.Write(a);

    }
 

}