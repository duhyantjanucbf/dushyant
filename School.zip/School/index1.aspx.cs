﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;



public partial class _Default : System.Web.UI.Page
{
    public static int count = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["admin"] != null)
        {
            Button2.Visible = true;
        }
   //     else
        {
            Button1.Visible = false; 
        }
       /* if (HttpContext.Current.Session["admin"] == "admin")
        {
            string a = Session["a"].ToString();
            string b = Session["b"].ToString();
            string str = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lokesh\Desktop\School\App_Data\Db1.mdf;Integrated Security=True;User Instance=True";

            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from admin", con);
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataSet t = new DataSet();
            ad.Fill(t);
            string name = t.Tables[0].Rows[0]["name"].ToString();
            string pass = t.Tables[0].Rows[0]["password"].ToString();
        */

           // if (a == name.Trim() && b == pass.Trim())
            //{
            //    count = 1;

                // Label1.Text = t.Tables[0].Rows[0]["password"].ToString();
            //    ImageButton1.Visible = false;
    //  if (Session["admin"] == null)
      //{
        //  Response.Redirect("unauthorised.aspx");
      //}
               //if (HttpContext.Current.Session["admin"] == "admin")
              // {
              // Button2.Visible=true;
                   
               //}

            }
            

        protected void  Button2_Click(object sender, EventArgs e)
{
    if (Session["admin"] != null)
    {
        // Session.RemoveAll();  
        Session.RemoveAll();
        Response.Redirect("admin.aspx");
        
    }
   


    
}




    

    protected void ImageButton1_Click1(object sender, ImageClickEventArgs e)
    {

        Response.Redirect("loginn.aspx");
    }
    protected void BulletedList1_Click(object sender, BulletedListEventArgs e)
    {
        if (count == 1)
        { 
        
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        count = 2;
        BulletedList b1 = new BulletedList();
        
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        
    }
  
}
