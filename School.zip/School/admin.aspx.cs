﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class admin : System.Web.UI.Page
{ 
    int a = 0;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        Label4.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lokesh\Documents\Visual Studio 2010\WebSites\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            SqlDataAdapter d = new SqlDataAdapter();
            DataTable t = new DataTable();
            d = new SqlDataAdapter("select * from admin", con);
            d.Fill(t);
            if (TextBox1.Text == (t.Rows[0]["name"].ToString()).Trim() && TextBox2.Text == (t.Rows[0]["password"].ToString()).Trim())
            {
                //HttpContext.Current.Session["a"] = TextBox1.Text;
                //HttpContext.Current.Session["b"] = TextBox2.Text;
                if (t.Rows.Count == 1)
                {
                    //HttpContext.Current.Session["admin"] = "admin";
                    Session["admin"] = "admin";
                    Response.Redirect("home.aspx");
                    //Session.RemoveAll();

                }
                else
                {
                Label4.Text = "Invaild User Name Or Password";
                Label4.Visible = true;
                Label4.ForeColor = System.Drawing.Color.Red; 
            }
            }
           else
                {
                Label4.Text = "Invaild User Name Or Password";
                Label4.Visible = true;
                Label4.ForeColor = System.Drawing.Color.Red; 
            }
    }

      /*      if (TextBox1.Text == "admin" & TextBox2.Text == "admin")
            {

                HttpContext.Current.Session["a"]= TextBox1.Text;
                HttpContext.Current.Session["b"] = TextBox2.Text;
                HttpContext.Current.Session["admin"] = "admin";
                Response.Redirect("index.aspx");

            }
            else
            {
                Label4.Enabled = true;
                Label4.Text = "incorrect Id or Password";
            }*/
        }
    
