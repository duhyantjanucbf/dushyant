﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class gal : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label6.Visible = true;
        Button2.Visible = false;
        if (Session["admin"] != null)
        {
            Label6.Visible = false;
           Button2.Visible = true;
         //  Button1.Visible = false;
           
            // Label2.Visible = false;
        }
        else if (Session["student"] != null)
        {
            Label6.Visible = false;
           Button2.Visible = true;
        //   Button1.Visible = false;
        }
        else if (Session["teacher"] != null)
        {
            Label6.Visible = false;
            Button2.Visible = true;
          //  Button1.Visible = false;
        }


    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("campus.aspx");
    }
    protected void ImageButton2_Click1(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("events.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        if (Session["admin"] != null)
        {
            // Session.RemoveAll();  
            Session.RemoveAll();
            //  Session["abc"] = "abc";
            Response.Redirect("index.aspx");

        }

        else if (Session["student"] != null)
        {
            // Session.RemoveAll();  
            Session.RemoveAll();
            //  Session["abc"] = "abc";
            Response.Redirect("index.aspx");

        }

        if (Session["teacher"] != null)
        {
            // Session.RemoveAll();  
            Session.RemoveAll();
            //Session["abc"] = "abc";
            Response.Redirect("index.aspx");

        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("loginn.aspx");
    }
}