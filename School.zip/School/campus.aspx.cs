﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing.Drawing2D;
using System.Data.SqlClient;
using System.Data;
public partial class campus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Button1.Visible = true;
        Button3.Visible = false;
    //    Label2.Visible = false;
        if (Session["admin"] != null)
        {
            Button1.Visible = false;
            Button2.Visible = true;
            Button3.Visible = true;

      //      Label2.Visible = true;
        }
        else if (Session["student"] != null)
        {
            Button1.Visible = false;
            Button2.Visible = false;
            Button3.Visible = true;

            Label1.Visible = false;
        }
        else if (Session["teacher"] != null)
        {
            Button1.Visible = false;
            Button3.Visible = true;

            Button2.Visible = false;
            Label1.Visible = false;
        }

        //   else { Response.Redirect("index.aspx"); }

        FileUpload2.Visible = false;
        Button2.Visible = false;
        if (Session["admin"] != null)
        {
            FileUpload2.Visible = true;
            Button2.Visible = true;
            foreach (string strfilename in Directory.GetFiles(Server.MapPath("~/data/")))
            {

                ImageButton imagebutton = new ImageButton();
                FileInfo fileinfo = new FileInfo(strfilename);
                imagebutton.ImageUrl = "~/data/" + fileinfo.Name;
                imagebutton.Width = Unit.Pixel(300);
                imagebutton.Height = Unit.Pixel(300);
                imagebutton.Style.Add("padding", "5px");
                //imagebutton.Click += new ImageClickEventHandler(imagebutton_Click);
                // imagebutton.OnClientClick += new imag



                Panel1.Controls.Add(imagebutton);

            }
        }
        else
        {
            FileUpload2.Visible = false;
            Button2.Visible = false;
            foreach (string strfilename in Directory.GetFiles(Server.MapPath("~/data/")))
            {

                ImageButton imagebutton = new ImageButton();
                FileInfo fileinfo = new FileInfo(strfilename);
                imagebutton.ImageUrl = "~/data/" + fileinfo.Name;
                imagebutton.Width = Unit.Pixel(300);
                imagebutton.Height = Unit.Pixel(300);
                imagebutton.Style.Add("padding", "5px");
                //imagebutton.Click += new ImageClickEventHandler(imagebutton_Click);
                // imagebutton.OnClientClick += new imag



                Panel1.Controls.Add(imagebutton);

            }
        }


    }
    protected void Button8_Click1(object sender, EventArgs e)
    {
       
    }

    void imagebutton_Click(object sender, ImageClickEventArgs e)
    {  //  string jsMethodName= = "NewPage()";
        //ScriptManager.RegisterClientScriptBlock(this, typeof(string), "uniqueKey", jsMethodName, true);
        //throw new NotImplementedException();
        //Response.Redirect("index.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("index.aspx");
    }
    
    protected void Button1_Click1(object sender, EventArgs e)
    {
        if (FileUpload2.HasFile)
        {
            string filename = FileUpload2.FileName;
            FileUpload2.PostedFile.SaveAs(Server.MapPath("~/data/" + filename));


        }
        foreach (string strfilename in Directory.GetFiles(Server.MapPath("~/data/")))
        {

            ImageButton imagebutton = new ImageButton();
            FileInfo fileinfo = new FileInfo(strfilename);
            imagebutton.ImageUrl = "~/data/" + fileinfo.Name;
            imagebutton.Width = Unit.Pixel(300);
            imagebutton.Height = Unit.Pixel(300);
            imagebutton.Style.Add("padding", "5px");
            //imagebutton.Click += new ImageClickEventHandler(imagebutton_Click);
            // imagebutton.OnClientClick += new imag



            Panel1.Controls.Add(imagebutton);
        }
        Response.Redirect("campus.aspx");
     
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("loginn.aspx");
    }
}