﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label6.Visible = true;
        Button2.Visible = false;
        if (Session["admin"] != null)
        {
            Label6.Visible = false;
            Button2.Visible = true;
            Button1.Visible = false;

            // Label2.Visible = false;
        }
        else if (Session["student"] != null)
        {
            Label6.Visible = false;
            Button2.Visible = true;
            Button1.Visible = false;
        }
        else if (Session["teacher"] != null)
        {
            Label6.Visible = false;
            Button2.Visible = true;
            Button1.Visible = false;
        }
        Label5.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text != "" && TextBox2.Text != "" && TextBox3.Text != "" && TextBox4.Text != "")
        {
            string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=G:\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            SqlDataAdapter d = new SqlDataAdapter();
            DataTable t = new DataTable();
            d = new SqlDataAdapter("insert into contactmsg values(@a,@b,@c,@d)", con);
            d.SelectCommand.Parameters.AddWithValue("a", TextBox1.Text);
            d.SelectCommand.Parameters.AddWithValue("b", TextBox2.Text.Trim());
            d.SelectCommand.Parameters.AddWithValue("c", TextBox3.Text);

            d.SelectCommand.Parameters.AddWithValue("d", TextBox4.Text);
            d.Fill(t);
        }
        else
        {
            Label5.Text = "Please fill all the fields first";
        }
           }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("index.aspx");
    }
}